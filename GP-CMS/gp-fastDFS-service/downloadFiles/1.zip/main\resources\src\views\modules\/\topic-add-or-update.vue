<template>
  <el-dialog
    :title="!dataForm.id ? '新增' : '修改'"
    :close-on-click-modal="false"
    :visible.sync="visible">
    <el-form :model="dataForm" :rules="dataRule" ref="dataForm" @keyup.enter.native="dataFormSubmit()" label-width="80px">
    <el-form-item label="课题老师工号" prop="tid">
      <el-input v-model="dataForm.tid" placeholder="课题老师工号"></el-input>
    </el-form-item>
    <el-form-item label="选题名称" prop="topicName">
      <el-input v-model="dataForm.topicName" placeholder="选题名称"></el-input>
    </el-form-item>
    <el-form-item label="创建时间" prop="createtime">
      <el-input v-model="dataForm.createtime" placeholder="创建时间"></el-input>
    </el-form-item>
    <el-form-item label="选题人数上限" prop="toplimit">
      <el-input v-model="dataForm.toplimit" placeholder="选题人数上限"></el-input>
    </el-form-item>
    <el-form-item label="选题状态:0可选,1不可选" prop="status">
      <el-input v-model="dataForm.status" placeholder="选题状态:0可选,1不可选"></el-input>
    </el-form-item>
    <el-form-item label="课题类型" prop="type">
      <el-input v-model="dataForm.type" placeholder="课题类型"></el-input>
    </el-form-item>
    <el-form-item label="课题内容简介" prop="content">
      <el-input v-model="dataForm.content" placeholder="课题内容简介"></el-input>
    </el-form-item>
    <el-form-item label="所属院系" prop="department">
      <el-input v-model="dataForm.department" placeholder="所属院系"></el-input>
    </el-form-item>
    <el-form-item label="所属专业" prop="science">
      <el-input v-model="dataForm.science" placeholder="所属专业"></el-input>
    </el-form-item>
    <el-form-item label="课题的要求条件" prop="demand">
      <el-input v-model="dataForm.demand" placeholder="课题的要求条件"></el-input>
    </el-form-item>
    <el-form-item label="学号" prop="stuId">
      <el-input v-model="dataForm.stuId" placeholder="学号"></el-input>
    </el-form-item>
    <el-form-item label="课题来源" prop="source">
      <el-input v-model="dataForm.source" placeholder="课题来源"></el-input>
    </el-form-item>
    <el-form-item label="已选人数" prop="selected">
      <el-input v-model="dataForm.selected" placeholder="已选人数"></el-input>
    </el-form-item>
    <el-form-item label="学生的培养目标" prop="stuTarget">
      <el-input v-model="dataForm.stuTarget" placeholder="学生的培养目标"></el-input>
    </el-form-item>
    <el-form-item label="备注" prop="remarks">
      <el-input v-model="dataForm.remarks" placeholder="备注"></el-input>
    </el-form-item>
    <el-form-item label="审批状态:-1未通过,0待提交审核,1审核中2审核通过" prop="approvalStatus">
      <el-input v-model="dataForm.approvalStatus" placeholder="审批状态:-1未通过,0待提交审核,1审核中2审核通过"></el-input>
    </el-form-item>
    <el-form-item label="课题所归属学院id" prop="deptId">
      <el-input v-model="dataForm.deptId" placeholder="课题所归属学院id"></el-input>
    </el-form-item>
    <el-form-item label="审批驳回意见" prop="opinions">
      <el-input v-model="dataForm.opinions" placeholder="审批驳回意见"></el-input>
    </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="dataFormSubmit()">确定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  export default {
    data () {
      return {
        visible: false,
        dataForm: {
          topicId: 0,
          tid: '',
          topicName: '',
          createtime: '',
          toplimit: '',
          status: '',
          type: '',
          content: '',
          department: '',
          science: '',
          demand: '',
          stuId: '',
          source: '',
          selected: '',
          stuTarget: '',
          remarks: '',
          approvalStatus: '',
          deptId: '',
          opinions: ''
        },
        dataRule: {
          tid: [
            { required: true, message: '课题老师工号不能为空', trigger: 'blur' }
          ],
          topicName: [
            { required: true, message: '选题名称不能为空', trigger: 'blur' }
          ],
          createtime: [
            { required: true, message: '创建时间不能为空', trigger: 'blur' }
          ],
          toplimit: [
            { required: true, message: '选题人数上限不能为空', trigger: 'blur' }
          ],
          status: [
            { required: true, message: '选题状态:0可选,1不可选不能为空', trigger: 'blur' }
          ],
          type: [
            { required: true, message: '课题类型不能为空', trigger: 'blur' }
          ],
          content: [
            { required: true, message: '课题内容简介不能为空', trigger: 'blur' }
          ],
          department: [
            { required: true, message: '所属院系不能为空', trigger: 'blur' }
          ],
          science: [
            { required: true, message: '所属专业不能为空', trigger: 'blur' }
          ],
          demand: [
            { required: true, message: '课题的要求条件不能为空', trigger: 'blur' }
          ],
          stuId: [
            { required: true, message: '学号不能为空', trigger: 'blur' }
          ],
          source: [
            { required: true, message: '课题来源不能为空', trigger: 'blur' }
          ],
          selected: [
            { required: true, message: '已选人数不能为空', trigger: 'blur' }
          ],
          stuTarget: [
            { required: true, message: '学生的培养目标不能为空', trigger: 'blur' }
          ],
          remarks: [
            { required: true, message: '备注不能为空', trigger: 'blur' }
          ],
          approvalStatus: [
            { required: true, message: '审批状态:-1未通过,0待提交审核,1审核中2审核通过不能为空', trigger: 'blur' }
          ],
          deptId: [
            { required: true, message: '课题所归属学院id不能为空', trigger: 'blur' }
          ],
          opinions: [
            { required: true, message: '审批驳回意见不能为空', trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      init (id) {
        this.dataForm.topicId = id || 0
        this.visible = true
        this.$nextTick(() => {
          this.$refs['dataForm'].resetFields()
          if (this.dataForm.topicId) {
            this.$http({
              url: this.$http.adornUrl(`///topic/info/${this.dataForm.topicId}`),
              method: 'get',
              params: this.$http.adornParams()
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.dataForm.tid = data.topic.tid
                this.dataForm.topicName = data.topic.topicName
                this.dataForm.createtime = data.topic.createtime
                this.dataForm.toplimit = data.topic.toplimit
                this.dataForm.status = data.topic.status
                this.dataForm.type = data.topic.type
                this.dataForm.content = data.topic.content
                this.dataForm.department = data.topic.department
                this.dataForm.science = data.topic.science
                this.dataForm.demand = data.topic.demand
                this.dataForm.stuId = data.topic.stuId
                this.dataForm.source = data.topic.source
                this.dataForm.selected = data.topic.selected
                this.dataForm.stuTarget = data.topic.stuTarget
                this.dataForm.remarks = data.topic.remarks
                this.dataForm.approvalStatus = data.topic.approvalStatus
                this.dataForm.deptId = data.topic.deptId
                this.dataForm.opinions = data.topic.opinions
              }
            })
          }
        })
      },
      // 表单提交
      dataFormSubmit () {
        this.$refs['dataForm'].validate((valid) => {
          if (valid) {
            this.$http({
              url: this.$http.adornUrl(`///topic/${!this.dataForm.topicId ? 'save' : 'update'}`),
              method: 'post',
              data: this.$http.adornData({
                'topicId': this.dataForm.topicId || undefined,
                'tid': this.dataForm.tid,
                'topicName': this.dataForm.topicName,
                'createtime': this.dataForm.createtime,
                'toplimit': this.dataForm.toplimit,
                'status': this.dataForm.status,
                'type': this.dataForm.type,
                'content': this.dataForm.content,
                'department': this.dataForm.department,
                'science': this.dataForm.science,
                'demand': this.dataForm.demand,
                'stuId': this.dataForm.stuId,
                'source': this.dataForm.source,
                'selected': this.dataForm.selected,
                'stuTarget': this.dataForm.stuTarget,
                'remarks': this.dataForm.remarks,
                'approvalStatus': this.dataForm.approvalStatus,
                'deptId': this.dataForm.deptId,
                'opinions': this.dataForm.opinions
              })
            }).then(({data}) => {
              if (data && data.code === 0) {
                this.$message({
                  message: '操作成功',
                  type: 'success',
                  duration: 1500,
                  onClose: () => {
                    this.visible = false
                    this.$emit('refreshDataList')
                  }
                })
              } else {
                this.$message.error(data.msg)
              }
            })
          }
        })
      }
    }
  }
</script>
