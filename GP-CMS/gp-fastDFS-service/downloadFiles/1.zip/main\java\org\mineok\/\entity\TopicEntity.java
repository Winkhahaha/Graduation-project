package org.mineok./.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * 
 * @author GaoMing
 * @email mineok@foxmail.com
 * @date 2020-12-10 14:08:08
 */
@Data
@TableName("tb_topic")
public class Topic implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	@TableId
	private Integer topicId;
	/**
	 * 课题老师工号
	 */
	private String tid;
	/**
	 * 选题名称
	 */
	private String topicName;
	/**
	 * 创建时间
	 */
	private Date createtime;
	/**
	 * 选题人数上限
	 */
	private Integer toplimit;
	/**
	 * 选题状态:0可选,1不可选
	 */
	private Integer status;
	/**
	 * 课题类型
	 */
	private String type;
	/**
	 * 课题内容简介
	 */
	private String content;
	/**
	 * 所属院系
	 */
	private String department;
	/**
	 * 所属专业
	 */
	private String science;
	/**
	 * 课题的要求条件
	 */
	private String demand;
	/**
	 * 学号
	 */
	private String stuId;
	/**
	 * 课题来源
	 */
	private String source;
	/**
	 * 已选人数
	 */
	private Integer selected;
	/**
	 * 学生的培养目标
	 */
	private String stuTarget;
	/**
	 * 备注
	 */
	private String remarks;
	/**
	 * 审批状态:-1未通过,0待提交审核,1审核中2审核通过
	 */
	private Integer approvalStatus;
	/**
	 * 课题所归属学院id
	 */
	private Integer deptId;
	/**
	 * 审批驳回意见
	 */
	private String opinions;

}
