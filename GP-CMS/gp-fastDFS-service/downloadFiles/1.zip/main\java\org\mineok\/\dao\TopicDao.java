package org.mineok./.dao;

import org.mineok./.entity.TopicEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * 
 * @author GaoMing
 * @email mineok@foxmail.com
 * @date 2020-12-10 14:08:08
 */
@Mapper
public interface TopicDao extends BaseMapper<TopicEntity> {
	
}
